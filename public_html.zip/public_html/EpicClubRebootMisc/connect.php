<?php
$servername = "localhost";
$username = "id16116331_rgergergergergergergerg";
$password = "B2&23@=Y/IzaNGFi";
$database = "id16116331_fergregergergergregerg";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
